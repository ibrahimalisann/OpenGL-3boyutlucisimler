
//Bir g�r�nt�y� temsil eder
class Foto {
public:Foto(char* pik, int gen, int boy);
	  ~Foto();

	  char* pixels; //piksel piksel gorme 
	  int genislik;
	  int y�kseklik;
};

//Dosyadan bitmap uzant�l� fotoyu g�rme
Foto* loadBMP(const char* filename);





