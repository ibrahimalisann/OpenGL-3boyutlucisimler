
#include <iostream>
#include <stdlib.h>
#include <GL/glut.h>                   
#include "Kaplama.h"   


/*
*201713172807
*�brahim Ali�an
2.��retim
*/

GLfloat  aciPiramit = 0.0f;
GLfloat  aciKup = 0.0f;
int  t_yenileme = 15;	//  milisaniye  cinsinden  yenileme  aral���

GLuint textureCat;           //Kedinin texture id'si
GLuint  textureDog;           //Kopegin texture id'si


float xgoturKup = 0, ygoturKup = 0, zgoturKup = 0;
float xgoturPrmt = 0, ygoturPrmt = 0, zgoturPrmt = 0;
float derece = 0;                        //saga sola d�nd�rme




void Ayarlar(void);
void CizimFonksiyonu(void);
void GorunumAyari(int en, int boy);           //tam ekran yapt�g�m�zda sekilde bozulma olmasin hemde sekile acili bakicagiz 
void Kup(void);
void Piramit(void);
void ResmiY�kle(void);



/*Not: G�r�nt�y� bir texture'a d�n��t�r�yoruz ve sonras�nda texture�in texture'sini d�nd�r�yoruz.Burada ula�mak istedi�imiz verilere Imageloader.h s�n�f�ndan ula��yoruz*/

GLuint loadTexture(Foto* foto) {
    GLuint textureId;
    glGenTextures(1, &textureId);                      //texture'a haf�zada yer a��yoruz ve bu texture id al�yor ald�g� id ise gluint basit olarak unsigned integer
    glBindTexture(GL_TEXTURE_2D, textureId);        // openGL'ye hangi texture'nin d�zenlenece�ini s�yl�yoruz ve �al��mak istedi�imiz resmi o texture ile e�le�tiriyoruz 
    glTexImage2D(GL_TEXTURE_2D,                     //Resimimiz 2D oldu�u i�in bu �a�r�y� yap�yoruz               
        0,                                             //ba�ta s�f�r olarak tan�mlad�k
        GL_RGB,                                         //  GL_RGB format� openGL i�in kullan�l�r 
        foto->genislik, foto->y�kseklik,                        //geni�lik ve y�kseklik  ata s�n�f�nda olan  fonksiyonunu �al��t�racakt�r.
        0,                                                  //ekledigimiz fotograf�n s�n�r�
        GL_RGB,                                            // RGB format�nda pikselleri sakl�yoruz 
        GL_UNSIGNED_BYTE,                               //Ayn� �ekilde pikseller unsigned olarak saklan�r
        foto->pixels);                                   //Pikselin verilerini al�yoruz  
    return textureId;                                    //textureId ye geri d�n�� 
}


void ResmiY�kle(void) {
    glEnable(GL_DEPTH_TEST);                                                 //Derinlik testi
    glEnable(GL_LIGHTING);	                                                 //Tepe rengini hesaplamak i�in mevcut ayd�nlatma parametresi	
    glEnable(GL_LIGHT0);                                                     //0*4000.ci ����� dahil ediyoruz 
    glEnable(GL_NORMALIZE);                                                 //D�n���mden sonra ve ayd�nlatma �ncesi birim uzunlu�una normalize etme
    glEnable(GL_COLOR_MATERIAL);                                            // mevcut rengi izlemek i�in ortam ve da��n�k malzeme	parametrelerini kabul etme


    Foto* kediFoto = loadBMP("kedi.bmp");                         //cat.bmp adl� fotograf� y�kl�yorz. kediFoto objesinin i�erisine y�kl�yoruz
    textureCat = loadTexture(kediFoto);                            //load texture'� openGL in i�erisine girmek i�in �a��r�yoruz
    delete kediFoto;                                               //openGL bu piksel dizisini kopyal�yor  ve art�k burada bir piksel dizisine ihtiya� duymuyoruz b�ylece tan�mlad���m�z image'i  silebiliriz
    Foto* kopekFoto = loadBMP("kopek.bmp");
    textureDog = loadTexture(kopekFoto);
    delete kopekFoto;
}

//Hareket ettirme 
void GoturSagKup(void) {
    glLoadIdentity();                 //Koordinat sistemimiz etkilenmesin 
    xgoturKup += 0.1;
}
void GoturSagPrmt(void) {
    glLoadIdentity();
    xgoturPrmt += 0.1;
}

void GoturSolKup(void) {
    glLoadIdentity();
    xgoturKup -= 0.1;
}
void GoturSolPrmt(void) {
    glLoadIdentity();
    xgoturPrmt -= 0.1;
}

void GoturYukar�Kup(void) {
    glLoadIdentity();
    ygoturKup += 0.1;
}
void GoturYukar�Prmt(void) {
    glLoadIdentity();
    ygoturPrmt += 0.1;
}

void GoturAsagiKup(void) {
    glLoadIdentity();
    ygoturKup -= 0.1;
}
void GoturAsagiPrmt(void) {
    glLoadIdentity();
    ygoturPrmt -= 0.1;
}

void GoturIleriKup(void) {
    glLoadIdentity();
    zgoturKup -= 0.1;
}
void GoturIleriPrmt(void) {
    glLoadIdentity();
    zgoturPrmt -= 0.1;
}

void GoturGeriKup(void) {
    glLoadIdentity();
    zgoturKup += 0.1;
}
void GoturGeriPrmt(void) {
    glLoadIdentity();
    zgoturPrmt += 0.1;
}


void CevirSagKup(void) {
    glLoadIdentity();
    derece += 0.5;
}
void CevirSagPrmt(void) {
    glLoadIdentity();
    derece += 0.5;
}

void CevirSolKup(void) {
    glLoadIdentity();
    derece -= 0.5;
}
void CevirSolPrmt(void) {
    glLoadIdentity();
    derece -= 0.5;
}

void Ayarlar(void)
{

  glClearColor(0.0f, 0.5f, 1.0f, 0.0f); //bebek mavisi    //red,green ,blue ,alpha
   // glClearColor(2.0f, 0.5f, 1.0f, 0.0f); //Leylak (kedi i�in)
  
   // glClearColor(0.1, 0.0, 0.0, 0.0);  //kahverengi(kopek i�in)

    glClearDepth(1.0f);
    glEnable(GL_DEPTH_TEST);                                     //z ekseni i�in derinlik testi
    glDepthFunc(GL_LEQUAL);                                      //karma��k grafiklerde derinlik testi o an ekrandaki tamponda saklanan z degeri e�it ise true d�nd�r�r
    glShadeModel(GL_SMOOTH);                                    //d�zg�n g�lgelendirme
    glHint(GL_PERSPECTIVE_CORRECTION_HINT, GL_NICEST);           //perspektif ayarlamalar�
    glColor3d(0.0, 0.0, 0.0);
}

void Piramit(void) {              // Piramidi  �izmeye ba�la.

    glLoadIdentity();               //Primadin �l�eklenmemesi i�in 

    glTranslatef(1.5f, 0.0f, -6.0f);        //sola ve geriye �tele 
    glTranslatef(xgoturPrmt, ygoturPrmt, zgoturPrmt);
    glRotatef(derece, 1.0, 1.0, 1.0);
    glRotatef(aciPiramit, -1.0f, 1.0f, 0.0f);                    // -x ve y etraf�nda d�n��


    glEnable(GL_TEXTURE_2D);
    glBindTexture(GL_TEXTURE_2D, textureDog);
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR);    //2.si uzakl��� kameraya
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);     //2.si yak�nl���    3.s�  bloklu doku e�leme yerine bulan�k doku e�leme
    glBegin(GL_TRIANGLES);


    //�n y�z 

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);      //Beyaz rengin koordinatlar� 
    glNormal3f(0.0, 0.0f, 1.0f);

    glTexCoord2f(0.5f, 1.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
   

    glTexCoord2f(-0.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);


    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);



    //arka y�z  

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);                                                      //BEYAZ
    glNormal3f(0.0, 0.0f, -1.0f);

    glTexCoord2f(0.5f, 1.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
  
    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);

    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);

    //sag y�z 

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
    glNormal3f(0.0, 0.0f, 1.0f);

    glTexCoord2f(0.5f, 1.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
    glNormal3f(0.0, 1.0f, 0.0f);

    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, 1.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1.0f, -1.0f, -1.0f);

    //sol y�z  

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
    glNormal3f(0.0, 0.0f, 1.0f);

    glTexCoord2f(0.5f, 1.0f);
    glVertex3f(0.0f, 1.0f, 0.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
  

    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, -1.0f);

    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);
    
    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1.0f, -1.0f, 1.0f);

    glEnd();	//  Piramit  �izimi  bitti


    glDisable(GL_TEXTURE_2D);

}
void HareketPrmt(unsigned char Prmt, int xPrmt, int yPrmt) {                    //yaln�zca karakter tu�lar�
    switch (Prmt)
    {
    case 'a': GoturSolPrmt(); break;
    case 'd': GoturSagPrmt(); break;
    case 'w': GoturYukar�Prmt(); break;
    case 's': GoturAsagiPrmt(); break;
    case '+': GoturIleriPrmt(); break;
    case '-': GoturGeriPrmt(); break;
    }
    glutPostRedisplay();                                    //hareket(i�lem) sonras� g�ncelleme i�in
}


void Kup(void) {
    glLoadIdentity();
    glTranslatef(-2.0f, 0.0f, -7.0f);	//  �ekli  sa�a  ve  geriye  kayd�r
    glTranslatef(xgoturKup, ygoturKup, zgoturKup);
    glRotatef(derece, 2.0, 1.0, 0.0);


    glRotatef(aciKup, 1.0f, 1.0f, 0.0f);	//  Rotate  (1,1,0)-axis  (x ve y -ekseni  etraf�nda  d�n��)

    glEnable(GL_TEXTURE_2D);                     //Texture_2d yi enable ettik 
    glBindTexture(GL_TEXTURE_2D, textureCat);           // �izece�imiz �okgenler ne olursa olsun adland�r�lm�� bir texture olu�turmaya veya kullanmaya izin verir,1.paratme setlemek istedi�imiz target,2.parametre ise texture'nin ad�d�d�r.                            bu texture'yi bu �zel id  ile kimli�e uygulamak istedi�imizi s�ylemek i�in
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MIN_FILTER, GL_LINEAR); // GlTextureParameter i�levleri i�in ;1.parametre target,2.parametre tek de�erli bir texture parametresinin sembolik ad�n� belirtir,3.parametre ise lineer olmas� 
    glTexParameteri(GL_TEXTURE_2D, GL_TEXTURE_MAG_FILTER, GL_LINEAR);
    
  



    //�st y�z 
    glBegin(GL_QUADS);

    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);      //beyaz
    glNormal3f(0.0, 1.0f, 0.0f);        // y�ze dik vekt�r� normal vekt�re vermek

    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1, 1, -1);

    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1, 1, 1);

    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1, 1, 1);

    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(1, 1, -1);




    //alt y�z 

    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);       //cismin rengi Beyaz
    glNormal3f(0.0, -1.0f, 0.0f);

    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1, -1, -1);

    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1, -1, -1);

    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1, -1, 1);

   glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-1, -1, 1);

    glEnd();


    //�n y�z 
    glBegin(GL_QUADS);
   
    glColor4f(1.0f, 1.0f, 1.0f, 0.0f);//white
    glNormal3f(0.0, 0.0f, 1.0f);

    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1, -1, 1);                 

    glTexCoord2f(1.0f, 0.0f); 
    glVertex3f(1, -1, +1);           

    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1, 1, 1);

    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-1, 1, 1);


    //arka y�z 

    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);       //cismin rengi Beyaz
    glNormal3f(0.0, 0.0f, -1.0f);

    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1, -1, -1);

    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1, 1, -1);

    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1, 1, -1);

    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(1, -1, -1);
    glEnd();


    //sol y�z 
    glBegin(GL_QUADS);
    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);       //cismin rengi Beyaz
    glNormal3f(-1.0, 0.0f, 0.0f);

    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(-1, -1, -1);

        glTexCoord2f(1.0f, 0.0f);
    glVertex3f(-1, -1, 1);

    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(-1, 1, 1);

    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(-1, 1, -1);


    //sag y�z 

    glColor4f(1.0f, 1.0f, 1.0f, 1.0f);       //cismin rengi Beyaz
    glNormal3f(1.0, 0.0f, 0.0f);


    glTexCoord2f(0.0f, 0.0f);
    glVertex3f(+1, -1, -1);

    glTexCoord2f(1.0f, 0.0f);
    glVertex3f(1, 1, -1);

    glTexCoord2f(1.0f, 1.0f);
    glVertex3f(1, 1, 1);

    glTexCoord2f(0.0f, 1.0f);
    glVertex3f(1, -1, 1);


    glDisable(GL_TEXTURE_2D);
    glEnd();

}

void HareketKup(int Kup, int xKup, int yKup) {                    //�zel i�lev tu�lar�
    switch (Kup)
    {
    case GLUT_KEY_LEFT: GoturSolKup(); break;
    case GLUT_KEY_RIGHT: GoturSagKup(); break;
    case GLUT_KEY_UP: GoturYukar�Kup(); break;
    case GLUT_KEY_DOWN: GoturAsagiKup(); break;
    case GLUT_KEY_PAGE_UP: GoturIleriKup(); break;
    case GLUT_KEY_PAGE_DOWN: GoturGeriKup(); break;
    }
    glutPostRedisplay();                                    //hareket(i�lem) sonras� g�ncelleme i�in
}


void CizimFonksiyonu(void)
{
    glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);       //silme i�lemi //hafiza alani
    glMatrixMode(GL_MODELVIEW);                             //
    glLoadIdentity();                    //�izecegimiz �ekil d�nmesin diye

    gluLookAt(0.0, 0.0, 2.0, 0.0, 0.0, 0.0, 0.0, 1.0, 0.0);
    //ekrana bakma yerimiz 9 parametre
    // kameran�n sabitlenecegi yerx0,y0,z0,
    //x1,y1,z1 kamera y�nlendirme y�n�m�z orijin
    // x2,y2,z2 kamera tutma. kamera y eksenine dik duruyor


    glTranslatef(0.0, 0.0, -2.0);                     //kamera modelden belirli bir oranda uzaklass�n(z ekseninde 2 br uzaktan baks�n)

    GLfloat ambientLight[] = { 0.3f, 0.3f, 0.3f, 1.0f };                //sahnenin her yerinde g�r�lebilmesi i�in
    glLightModelfv(GL_LIGHT_MODEL_AMBIENT, ambientLight);

    GLfloat lightColor[] = { 0.7f, 0.7f, 0.7f, 1.0f };
    GLfloat lightPos[] = { -2 * 0.5f,0.5f, 4 * 0.5f, 1.0f }; //bulunan 2 kutu boyutu solda, 1 kutu �stte ve4 kutu ekran�n d��ar�s�nda son parametre ise buras� 1 ��nk� bayt kayna�� y�nlendirdi�imiz ���k kayna��d�r
    glLightfv(GL_LIGHT4, GL_DIFFUSE, lightColor);  //���k kayna�� parametrelerini ayarlama:1.parametle ����� belirtir,2.parametre ise I��k i�in bir ���k kayna�� parametresi belirtir,Son parametre ise I��k kayna�� �����n�n ayarlanaca�� de�erin veya de�erlerin i�aret�isini belirtir.
    glLightfv(GL_LIGHT4, GL_POSITION, lightPos);

    glRotatef(-derece, 1.0f, 1.0f, 0.0f);

    Piramit();
    Kup();

    glutSwapBuffers();

   aciPiramit += 0.2f;
    aciKup -= 0.3f;
   
}


void  zamanlayici(int  deger) {
    glutPostRedisplay();  //CizimFonksiyonu()'nun  yapt���  i�lem  sonras�  g�ncelleme  i�in 
    glutTimerFunc(t_yenileme, zamanlayici, 0);  //  next  timer  call  milliseconds  later
}



void GorunumAyari(int en, int boy) {

    float oran = (float)en / (float)boy;
    glViewport(0, 0, en, boy);            //ilk iki deger ekran�n baslang�c�n neresinde olucak 
    glMatrixMode(GL_PROJECTION);        //izd�s�m g�r�n�m� ayarlamak i�in 
    glLoadIdentity();
    gluPerspective(45.0, oran, 1.0, 20.0);              //(perspektif a��s�,oran,kameran�n cisme en yak�n ,en uzak)

}





int main(int argc, char** argv)
{
    glutInit(&argc, argv); //glut yordamlar�n� ba�latmak i�in kullan�l�r.
     
    glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGB | GLUT_DEPTH);//�ift tampon(arabellek) kullanal�m.
    glutInitWindowPosition(100, 100); //pencere ba�lang�� noktas�
    glutInitWindowSize(800, 500); //Pencere geni�lik ve y�kseklik(en ,boy)
   // glutCreateWindow("Bilgisayar Grafikleri Dersi Final �devi"); //pencere ba�l���
    glutCreateWindow("Tesekkurler"); //pencere ba�l���



    ResmiY�kle();                    //resmi y�kleyen fonksiyon

    glutDisplayFunc(CizimFonksiyonu); //olu�an penceyi g�rebilmek i�in
    glutReshapeFunc(GorunumAyari);               //tam ekran yapt�g�m�zda sekilde bozulma olmasin 
    Ayarlar();
    glutTimerFunc(0, zamanlayici, 0);

    glutSpecialFunc(HareketKup);              //karakter tu�lar� i�in klavye 


    glutKeyboardFunc(HareketPrmt);              //�zel i�lev tu�lar� i�in 

    glutMainLoop();//�izim devaml� yap�lmal�(�izgi filmlerdeki gibi)
      //�izimi d�ng�ye sokar

    return 0;
}