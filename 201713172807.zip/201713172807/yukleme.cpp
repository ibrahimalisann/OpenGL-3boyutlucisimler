//kaynak kodlar 
#include <assert.h>
#include <fstream>

#include "Kaplama.h"

using namespace std;

Foto::Foto(char* pik, int gen, int boy) : pixels(pik), genislik(gen), y�kseklik(boy) {          //override 

}

Foto::~Foto() {
	delete[] pixels;
}

namespace {
	//Little-endian formunu kullanarak d�rt karakterlik bir diziyi integer'a d�n��t�r�r
	int toInt(const char* bytes) {
		return (int)(((unsigned char)bytes[3] << 24) |
			((unsigned char)bytes[2] << 16) |
			((unsigned char)bytes[1] << 8) |
			(unsigned char)bytes[0]);
	}

	//Little-endian formunu kullanarak iki karakterlik bir diziyi short'a d�n��t�r�r
	short toShort(const char* bytes) {
		return (short)(((unsigned char)bytes[1] << 8) |
			(unsigned char)bytes[0]);
	}

	//Little-endian formunu kullanarak sonraki d�rt bayt� tam say� olarak okur
	int readInt(ifstream& input) {
		char buffer[4];
		input.read(buffer, 4);
		return toInt(buffer);
	}

	//Little-endian formunu kullanarak sonraki iki bayt� short olarak okur
	short readShort(ifstream& input) {
		char buffer[2];
		input.read(buffer, 2);
		return toShort(buffer);
	}

	 //oto pointer gibi ama diziler i�in 
	template<class T>
	class auto_array {
	private:
		T* array;
		mutable bool isReleased;
	public:
		explicit auto_array(T* array_ = NULL) :
			array(array_), isReleased(false) {
		}

		auto_array(const auto_array<T>& oarray) {									//oto array nesnesini olu�turma
			array = oarray.array;
			isReleased = oarray.isReleased;                                                  //serbest b�rakma pointer��
			oarray.isReleased = true;                                                              //�yleyse true d�nd�r�r
		}


		~auto_array() {
			if (!isReleased && array != NULL) {														//eger bos delete ile belle�i sertbest birak
				delete[] array;
			}
		}

		T* get() const {														//i�aret�iyi al ve array isimli de�i�kene d�nd�r
			return array;
		}

		T& operator*() const {                                                   //adresteki deferans nesnesini al ve array 'e d�nd�r
			return *array;
		}

		void operator=(const auto_array<T>& oarray) {				//serbest b�rak�lmas�ysa ve bo� de�ilse serbest b�rak
			if (!isReleased && array != NULL) {
				delete[] array;
			}
			array = oarray.array;
			isReleased = oarray.isReleased;
			oarray.isReleased = true;							//e�itle ve true d�nd�r

		}

		T* operator->() const {											//atas�ndaki constractor�a ula� ve array�e d�nd�r
			return array;
		}

		T* release() {														//serbest b�rakma fonksiyonu
			isReleased = true;
			return array;
		}

		void reset(T* array_ = NULL) {
			if (!isReleased && array != NULL) {
				delete[] array;
			}
			array = array_;
		}

		T* operator+(int i) {
			return array + i;
		}

		T& operator[](int i) {
			return array[i];
		}
	};
}
// BMP Uzant�l� fotograf�m�z� cagiran fonksiyon
Foto* loadBMP(const char* filename) {
	ifstream input;
	input.open(filename, ifstream::binary);                       //filename�i ac ,binary olarak overload et
	assert(!input.fail() || !"Dosya bulunamad�");            //eger dosyay� bulamazsa alarm� 'dosya bulunamad� diye ver'
	char buffer[2];			//�� elemanl� bir tampon dizisi olu�tur
	input.read(buffer, 2);                               //oku
	assert(buffer[0] == 'B' && buffer[1] == 'M' || !"Bitmap dosyas� yok ");    //eger bitmap uzant�l� dosyam�z yoksa 'bitmap dosyas� yok' diye g�ster.
	input.ignore(8);															//klavyeden girilen ilk 8 girdiyi almad�k ignore�u                     						//kullanmazsak girdileri ayn� sat�rda yazar
	int dataOffset = readInt(input);             // ��levsel forma sahip bu makro, veri yap�s�nda veya birle�im t�r� t�r�nde �ye �yenin bayt cinsinden ofset de�erini d�nd�r�r.


   //Basligi oku
	int headerSize = readInt(input);
	int genislik;
	int y�kseklik;
	switch (headerSize) {
	case 40:
		//3.versiyon 
		genislik = readInt(input);
		y�kseklik = readInt(input);
		input.ignore(2);															//ilk 2 girdiyi atla
		assert(readShort(input) == 24 || !"G�r�nt� 24 bit degil");      //G�r�nt� 24 bit olarak y�klenmemis ise hatayi 'g�r�nt� 24 bit degil 'seklinde  g�ster
		assert(readShort(input) == 0 || !"G�r�nt� S�k�st�r�lm�s");		//eger g�r�nt� s�k��t�r�lm�s olarak y�klendiyse  hatayi 'g�r�nt� s�k��t�r�lm�s' olarak ver
		break;
	case 12:
		//OS/2 1.versiyonu (ibm-ve microsoft aras�nda bir anlasmazl�ktan dolay� iki sirket ayr�l�r ve OS/2 IBM'e d�ser)
		genislik = readShort(input);
		y�kseklik = readShort(input);
		input.ignore(2);																//ilk 2 girdiyi atla			
		assert(readShort(input) == 24 || !"G�r�nt� 24 bit degil");
		break;
	case 64:
		//OS/2 2.versiyonu
		assert(!" OS/2 V2 'nin bitmapleri y�klenemiyor");
		break;
	case 108:
		//Windows 4.versiyonu
		assert(!" Windows V4 bitmapleri y�klenemeyor");
		break;
	case 124:
		//Windows V5
		assert(!" Windows V5 bitmapleri y�klenemiyor");
		break;
	default:
		assert(!"Bilinmeyen bir bitmap formati");                 //Eger bu bitmap formatlar�ndan hi�biri degilse 'bilinmeyen bir bitmap format�'yaz�s�n� g�ster
	}

	//Veriyi okuyal�m 
	int bytesPerRow = ((genislik * 3 + 3) / 4) * 4 - (genislik * 3 % 4);		//sat�r ba��na byte�in hesaplanmas�
	int size = bytesPerRow * y�kseklik;											//her bir bytle ile y�ksekli�i �arp ve boyuta e�itle
	auto_array<char> pixels(new char[size]);                                     //piksel halini oto array dizisinde g�r
	input.seekg(dataOffset, ios_base::beg);											//dosyan�n belirli bir konumuna gitmek veya mevcut konumunu ��renmek i�in kullan�l�rlar.biz burada dosyaya ula��p ba��na gittik
	input.read(pixels.get(), size);												//pikselleri al�p boyutunca okuma 

	//Verileri do�ru bi�ime getirelim
	auto_array<char> pixels2(new char[genislik * y�kseklik * 3]);		//d�zg�n bir �ekile sokup hesaplanmas� 
	for (int y = 0; y < y�kseklik; y++) {								// y de�eri y�ksekli�e eri�inceye kadar artt�r
		for (int x = 0; x < genislik; x++) {						//ayn� zamanda x ile ilgili ayn� i�lemi yap 
			for (int c = 0; c < 3; c++) {							// ilk buradaki for�dan ba�la 
				pixels2[3 * (genislik * y + x) + c] =			//gerekli matematik i�lemleri
					pixels[bytesPerRow * y + 3 * x + (2 - c)];
			}
		}
	}

	input.close();										//girdiyi kapat
	return new Foto(pixels2.release(), genislik, y�kseklik);		//geriye d�nd�r
}









